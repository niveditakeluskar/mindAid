<?php

/*
|--------------------------------------------------------------------------
| RCare / RCareAdmin / AdminPackages / User Roles Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//logout
Route::get("/logout", "Auth\LoginController@logout")->name("logout");

    // //User Role CRUD
    // Route::get("/user-roles", "RCare\RCareAdmin\AdminPackages\UserRoles\src\Http\Controllers\UserRolesController@index")->name("user_roles");
    // Route::get("/user-role-list", "RCare\RCareAdmin\AdminPackages\UserRoles\src\Http\Controllers\UserRolesController@usersRolesList")->name("users_roles_list");
    // Route::post("/create-users-role", "RCare\RCareAdmin\AdminPackages\UserRoles\src\Http\Controllers\UserRolesController@createUsersRoles")->name("create_user_role");
    // Route::get('/ajax/rCare/edituserRoles/{id}/edit', 'RCare\RCareAdmin\AdminPackages\UserRoles\src\Http\Controllers\UserRolesController@editRoles');
    // Route::get('/changeRoleStatus/{id}', 'RCare\RCareAdmin\AdminPackages\UserRoles\src\Http\Controllers\UserRolesController@changeRoleStatus');
    // Route::post('update-user-role','RCare\RCareAdmin\AdminPackages\UserRoles\src\Http\Controllers\UserRolesController@updateUserRole')->name('update_user_role');
    // Route::post('/ajax/rCare/deleteRole/{id}/delete','RCare\RCareAdmin\AdminPackages\UserRoles\src\Http\Controllers\UserRolesController@deleteRole');

// Authenticated user only routes

Route::middleware(["guest","web"])->group(function () {

	Route::get("/", function () {
	    if(Auth::check()) {
	        return redirect('/dashboard');
	    } else {
	        return redirect('/rcare-login');
	    }
	})->name("login");
    Route::get("/rcare-login", "RCare\RCareAdmin\AdminPackages\Login\src\Http\Controllers\Auth\LoginController@index")->name("rcare-login");
    // Password reset link request routes... priyasingh95161@gmail.com
    Route::get('password/reset', 'RCare\RCareAdmin\AdminPackages\Login\src\Http\Controllers\Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
    Route::post('password/email', 'RCare\RCareAdmin\AdminPackages\Login\src\Http\Controllers\Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
    // Route::get('password/reset/{token}', 'RCare\RCareAdmin\AdminPackages\Login\src\Http\Controllers\Auth\ResetPasswordController@showResetForm')->name('password.request');
    Route::post('password/reset', 'RCare\RCareAdmin\AdminPackages\Login\src\Http\Controllers\Auth\ResetPasswordController@postReset')->name('password.reset');
});