<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Renova HealthCare</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/styles/css/themes/lite-purple.min.css')}}">
    <style>
     .error{
         color:red !important;
     }
 </style>

</head>

<body>
    <div class="auth-layout-wrap" style="background-image: url({{asset('assets/images/photo-wide-4.jpg')}})">
        <div class="auth-content">
            <div class="card o-hidden">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mt-4">
                            <div class="auth-logo text-center mb-4">
                                <img src="{{asset('assets/images/logo.png')}}" alt="">
                            </div>
                            <div class="text-center text-18">Sign In</div>
                            <form method="POST" action="{{ route('login') }}" name="login_form">
                                <div class="card-body">
                                    @if (\Session::has('errorMsg'))
                                    <div class="alert alert-danger">
                                        {!! \Session::get('errorMsg') !!}
                                    </div>
                                    @endif
                                    @csrf
                                    <div class="form-group row">
                                        <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                                        <div class="col-md-6">
                                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" autocomplete="email">

                                            @error('email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                                        <div class="col-md-6">
                                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" autocomplete="current-password">

                                            @error('password')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                       

                                    <div class="form-group row">
                                        <label for="loginuser" class="col-md-4 col-form-label text-md-right">LogIn As</label>
                                        <div class="col-md-6">
                                            <label class="radio radio-primary col-md-4 float-left">
                                                <input type="radio" checked id="role" name="role" value="1" formControlName="radio">
                                                <span>RCare</span>
                                                <span class="checkmark"></span>
                                            </label>
                                            <label class="radio radio-primary col-md-4 float-left">
                                                <input type="radio"  id="role" name="role" value="2" formControlName="radio">
                                                <span>Org</span>
                                                <span class="checkmark"></span>
                                            </label>
                                            <label class="radio radio-primary col-md-4 float-left">
                                                <input type="radio" id="role" name="role" value="3" formControlName="radio">
                                                <span>Partner</span>
                                                <span class="checkmark"></span>
                                            </label>
                                            <!--
                                            <select class="form-control @error('role') is-invalid @enderror" id="role" name="role">
                                                <option value="">Choose Role</option>
                                                <option value="1">Rcare</option>
                                                <option value="2">Organization(Renova Healthcare)</option>
                                                <option value="3">Partner</option>
                                            </select>
                                            -->
                                            @error('role')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-md-6 offset-md-4">
                                            <div class="">
                                                <label class=" checkbox checkbox-primary" for="remember">
                                                <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                                                <span>{{ __('Remember Me') }}</span>
                                                <span class="checkmark"></span>
                                                
                                                    
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    <!--div class="form-group row mb-0 card-header">
                                        <div class="col-md-8 offset-md-4">
                                            
                                        </div>
                                    </div-->
                                    <div class="card-footer">
                                        <div class="mc-footer">
                                            <div class="row">
                                                <div class="col-lg-12 text-center">
                                                <button type="submit" class="btn btn-primary">
                                                {{ __('Login') }}
                                            </button>

                                            @if (Route::has('password.request'))
                                                <!-- <a class="btn btn-link" href="{{ route('password.request') }}"> -->
                                                <a class="btn btn-link" href="{{route('password.request')}}">
                                                    {{ __('Forgot Your Password?') }}
                                                </a>
                                            @endif
                                                </div>
                                            </div>    
                                        </div>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <!-- JQUERY  -->
    <!--script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script-->
    <script src="{{asset('assets/js/common-bundle-script.js')}}"></script>

<script src="{{asset('assets/js/script.js')}}"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>


    <script type="text/javascript">
    $(function () {
    $("form[name='login_form']").validate({
         rules: {
            email: {
                        required: true,
                        email: true,
                    },
                    password: {
                        required: true,
                        minlength: 6,
                    },
                    role: {
                        required:true,
                    }


        },
        messages: {
            email: {
                required: "please Enter your E-Mail Id",
                email: "Your email address must be in the format of name@domain.com"
            },
              password: {
                required: "please Enter your Password",
                minlength: "Your password must be at least 6 characters long"
            },
             role: {
                required: "please choose  Role",
            },
        },
    });         
    });

</script>
   
</body>
</html>
