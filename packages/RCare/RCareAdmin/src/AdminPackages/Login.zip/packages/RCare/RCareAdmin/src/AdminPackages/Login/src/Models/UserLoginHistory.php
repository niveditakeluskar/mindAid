<?php

namespace RCare\RCareAdmin\AdminPackages\Users\src\Models;
use Illuminate\Database\Eloquent\Model;

class UserLoginHistory extends Model
{
    //
     protected $table ='rcare_admin.rcare_users_login_history';


      /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
	 
        protected $fillable = [
        'id',
        'login_time',
        'logout_time',
        'userid',
        'user_email',
        'mac_address',
        'ip_address',
        'login_attempt_status',
        'created_by',
        'updated_by',

    ];

    public function users(){
        return $this->belongsTo('RCare\RCareAdmin\AdminPackages\Users\src\Models\User','userid');
    }
   
}
