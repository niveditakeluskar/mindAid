 /**
 * Test-Form Javascript
 */
const URL_POPULATE = "/org/ajax/menu_populate";
const URL_SAVE     = "/org/ajax/menu_save"; //create_user_menu
const URL_UPDATE   = "/org/ajax/updateMenu";

/**
 * Invoked when the form is submitted
 *
 * @return {Boolean}
 */
var onSubmit = function () {
    // $('#menuModel').modal('hide');
    return true;
};

/**
 * Invoked when errors in the form are detected
 */
var onErrors = function (form, fields, response) {
    if (response.data.errors) {
        for (var field in response.data.errors) {
            try {
                let id = fields.fields[field].parents("[role='tabpanel']").attr("id");
            } catch (e) {
                console.error("Field Error:", field, fields.fields);
            }
        }
    }
    $("form[name='menuForm']").attr("action", URL_SAVE);
    return true;
};

/**
 * Invoked after the form has been submitted
 */
var onResult = function (form, fields, response, error) {
    if (error)
        console.log(error);
    if (response.status == 200) {
        notify.success("Menu Saved Successfully");
        $('#menuModel').modal('hide');
    } else {
        notify.danger("Save Failed: Unknown Error");
    }
};
/**
 * Populate the form of the given patient
 *
 * @param {Integer} patientId
 */
var populateForm = function(id) {
    // alert(id);
    if (!id)
        return;
    $.get(
        URL_POPULATE,
        {org_menu_id: id},
        function(data) {
            console.log(data);
            form.dynamicFormPopulate("menuForm", data);
            form.evaluateRules("menuForm");
        }
    ).fail(function(result) {
        console.error("Population Error:", result);
    });
};

var listData = function() {
    var columns= [
        {data: 'DT_RowIndex', name: 'DT_RowIndex'},
        {data: 'menu', name: 'menu'},
        {data: 'menu_url', name: 'menu_url'},
        {data: 'module.module', name: 'module.module'},
        {data: 'components.components', name: 'components.components'},
        {data: 'icon', name: 'icon'},
        {data: 'mnu.menu', name: 'mnu.menu'},
        {data: 'sequence', name: 'sequence'},
        {data: 'operations', "searchable": false, "orderable":false, "render": function (data, type, row) {
        if (row.operation === 'c') { return 'Create';}
        else if(row.operation === 'r' ){ return 'Read'; }
        else if(row.operation === 'u' ){ return 'Update'; }    
        else { return 'Delete';}}},
        {data: 'action', name: 'action', orderable: false, searchable: false},
    ];

    var table = util.renderDataTable('menu_list', "org_menu_list", columns, "{{ asset('') }}");
};

/**
 * Initialize the form
 */
var init = function () {

	$("#add-menu").click(function () {
        $("form[name='menuForm']").attr("action", URL_SAVE);
        $("form[name='menuForm']").submit();
    });

	$("#edit-menu").click(function () {
        $("form[name='menuForm']").attr("action", URL_UPDATE);
        $("form[name='menuForm']").submit();
    });

    $('#addMenu, .addmenu').click(function () {
        // var url = 'ajax/menu_save';
        $("#menuForm").attr("action",URL_SAVE);
        $(".is-invalid").removeClass("is-invalid");
        $('.invalid-feedback').html("");
        $("#button_div").html('<button type="submit" class="btn  btn-primary m-1" id="add-menu">Add Menu</button>');
        $('#menuModelHeading').html("Add Menu");
        $('#saveBtn').val("create-menu");
        $('#menu_name').val('');
        $('#menuForm').trigger("reset");
        $('#menuModel').modal('show');
    });
    
    $('body').on('click', '.editMenu', function () {
        // var url = 'update-user-menu';
        $("#menuForm").attr("action",URL_UPDATE);
        $(".is-invalid").removeClass("is-invalid");
        $('.invalid-feedback').html("");
        $("#button_div").html('<button type="submit" class="btn  btn-primary m-1" id="edit-menu">Save Changes</button>');
        var id = $(this).data('id');
        $('form[name="menuForm"]')[0].reset();
		$("[name='id']").val(id); // form cleared, so sets id again :)
        populateForm(id);
        $('#menuModelHeading').html("Edit Menu");
        $('#saveBtn').val("create-menu");
        $('#menuModel').modal('show');
    });
    $('body').on('click', '.change-status', function (){
        console.log('changed status');
        var confirm = confirm("Are you sure you want to Deactive this user?");
        if (confirm == true) {
            alert('yessss');
        } 
    });

    $(document).ready(function() { 
        if(window.location.href == 'http://rcareprototype.d-insights.global/org/menus#menuModel'){
       var url = 'ajax/menu_save';
        $("#menuForm").attr("action",URL_SAVE);
        $(".is-invalid").removeClass("is-invalid");
        $('.invalid-feedback').html("");
        $("#button_div").html('<button type="submit" class="btn  btn-primary m-1" id="add-menu">Add Menu</button>');
        $('#menuModelHeading').html("Add Menu");
        $('#saveBtn').val("create-menu");
        $('#menu_name').val('');
        $('#menuForm').trigger("reset");
        $('#menuModel').modal('show');
       }
    }); 
};

/**
 * Export the module
 */
window.orgmenus = {
    init: init,
    onErrors: onErrors,
    onResult: onResult,
    onSubmit: onSubmit
};
