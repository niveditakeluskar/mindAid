 /**
 * Test-Form Javascript
 */
const URL_POPULATE       = "/org/ajax/user_populate";
const URL_SAVE           = "/org/create-users"; //create_user_user
const URL_UPDATE         = "/org/ajax/updateUser";
const URL_REPORT_TO      = "/org/ajax/report-to";
const URL_LINKED_PRACTICES = "/org/ajax/linked-practices";
const URL_LINK_PRACTICES = "/org/ajax/link-practices";

/**
 * Invoked when the form is submitted
 *
 * @return {Boolean}
 */
var onSubmit = function () {
    // $('#user_modal').modal('hide');
    renderUserTable();
    return true;
};

/**
 * Invoked when errors in the form are detected
 */
var onErrors = function (form, fields, response) {
    if (response.data.errors) {
        for (var field in response.data.errors) {
            try {
                let id = fields.fields[field].parents("[role='tabpanel']").attr("id");
            } catch (e) {
                console.error("Field Error:", field, fields.fields);
            }
        }
    }
    // $("form[name='user_form']").attr("action", URL_SAVE);
    return true;
};

/**
 * Invoked after the form has been submitted
 */
var onResult = function (form, fields, response, error) {
    if (error)
        console.log(error);
    if (response.status == 200) {
        notify.success("User Saved Successfully");
        $('#user_modal').modal('hide');
    } else {
        notify.danger("Save Failed: Unknown Error");
    }
};
/**
 * Populate the form of the given patient
 *
 * @param {Integer} patientId
 */

var populateForm = function(id) {
    // alert(id);
    if (!id)
        return;
    $.get(
        URL_POPULATE,
        {id: id},
        function(data) {
            console.log(data);
            $("#edit-f-name").val(data.static.f_name);
            $("#edit-l-name").val(data.static.l_name);
            $("#edit-email").val(data.static.email);
            $("#edit-emp-id").val(data.static.emp_id);
            $("#edit-emp-status").val(data.static.status);
            $("#edit-emp-category_id").val(data.static.category_id);
             
            form.dynamicFormPopulate("user_form", data);
            form.evaluateRules("user_form");
        }
    ).fail(function(result) {
        console.error("Population Error:", result);
    });
};
/**
 * Set an user's name
 */
var onUserUpdateName = function (formObj, fields, response) {
    if (response.status == 200) {
        data[response.data.id] = response.data;
        renderUserTable();
        notify.success("User name updated successfully!");
    } else {
        console.error(response);
        notify.danger("An error occurred while changing the user's name!");
    }
};
/**
 * Set an user's email
 */
var onUserUpdateEmail = function (formObj, fields, response) {
    if (response.status == 200) {
        data[response.data.id] = response.data;
        renderUserTable();
        notify.success("User email updated successfully!");
    } else {
        console.error(response);
        notify.danger("An error occurred while changing the user's email!");
    }
};
/**
 * Set an user's status
 */
var onUserUpdateStatus = function (formObj, fields, response) {
    if (response.status == 200) {
        data[response.data.id] = response.data;
        renderUserTable();
        notify.success("User status updated successfully!");
    } else {
        console.error(response);
        notify.danger("An error occurred while changing the user's status!");
    }
};
/**
 * Set an user's Role
 */
var onUserUpdateRole = function (formObj, fields, response) {
    if (response.status == 200) {
        data[response.data.id] = response.data;
        renderUserTable();
        notify.success("User role updated successfully!");
    } else {
        console.error(response);
        notify.danger("An error occurred while changing the user's role!");
    }
};
/**
 * Set an user's Org
 */
var onUserUpdateOrg = function (formObj, fields, response) {
    if (response.status == 200) {
        data[response.data.id] = response.data;
        renderUserTable();
        notify.success("User org updated successfully!");
    } else {
        console.error(response);
        notify.danger("An error occurred while changing the user's org!");
    }
};
/**
 * Set an user's category
 */
var onUserUpdateCategory = function (formObj, fields, response) {
    if (response.status == 200) {
        data[response.data.id] = response.data;
        renderUserTable();
        notify.success("User category updated successfully!");
    } else {
        console.error(response);
        notify.danger("An error occurred while changing the user's category!");
    }
};
/**
 * Set an user's password
 */
var onUserUpdatePassword = function (formObj, fields, response) {
    if (response.status == 200) {
        data[response.data.id] = response.data;
        renderUserTable();
        notify.success("User password updated successfully!");
    } else {
        console.error(response);
        notify.danger("An error occurred while changing the user's password!");
    }
};
/**
 * Set an user's picture
 */
var onUserUpdatePicture = function (formObj, fields, response) {
    if (response.status == 200) {
        console.log(response.data);
        data[response.data.id] = response.data;
        renderUserTable();
        notify.success("User picture updated successfully!");
    } else {
        console.error(response);
        notify.danger("An error occurred while changing the user's picture!");
    }
};
/**
 * Set an user's practice link
 */
var onUserLinkPractice = function (formObj, fields, response) {
    if (response.status == 200) {
        console.log(response.data);
        data[response.data.id] = response.data;
        renderPracticeTable(response.data.user_id);
        renderUserTable();
        notify.success("User practice linked successfully!");
    } else {
        console.error(response);
        notify.danger("An error occurred while linking the user's practice!");
    }
};

var listData = function() {
    var columns = [
        {data: 'DT_RowIndex', name: 'DT_RowIndex'},
        {data: 'f_name', name: 'f_name'},
        {data: 'l_name', name: 'l_name'},
        {data: 'email', name: 'email'},
        {data: 'action', name: 'action', orderable: false, searchable: false},
    ]
    var table = util.renderDataTable('usersList', "{{ route('org_users_list') }}", columns, "{{ asset('') }}");

};

/**
 * Initialize the form
 */
var init = function () {

    $("#roles").change(function(){
        // console.log($(this).val());
        var role_id = $(this).val();
        $.get(URL_REPORT_TO,
            {role_id: role_id},
            function (data) {
                var model = $('#reports');
                model.empty();
                model.append("<option>Select Report To</option>");
                $.each(data, function (index, element) {
                    model.append("<option value='" + element.id + "'>" + element.f_name + " " + element.l_name + "</option>");
                });
            }
        );
    });

    $("#edit-roles").change(function(){
        // console.log($(this).val());
        var role_id = $(this).val();
        $.get(URL_REPORT_TO,
            {role_id: role_id},
            function (data) {
                var model = $('#edit-reports');
                model.empty();
                model.append("<option>Select Report To</option>");
                $.each(data, function (index, element) {
                    model.append("<option value='" + element.id + "'>" + element.f_name + " " + element.l_name + "</option>");
                });
            }
        );
    });

	$("#add-user").click(function () {
        $("form[name='user_form']").attr("action", URL_SAVE);
        $("form[name='user_form']").submit();
    });

    form.ajaxForm("name_details", onUserUpdateName);
    form.ajaxForm("change_status", onUserUpdateStatus);
    form.ajaxForm("change_role", onUserUpdateRole);
    form.ajaxForm("change_email", onUserUpdateEmail);
    form.ajaxForm("change_org", onUserUpdateOrg);
    form.ajaxForm("change_category", onUserUpdateCategory);
    form.ajaxForm("change_password", onUserUpdatePassword);
    form.ajaxForm("change_profile_image", onUserUpdatePicture);
    form.ajaxForm("edit_practice", onUserLinkPractice);

    $('#addUser').click(function () {
        $("#user_form").attr("action",URL_SAVE);
        $(".is-invalid").removeClass("is-invalid");
        $('.invalid-feedback').html("");
        $("#button_div").html('<button type="submit" class="btn  btn-primary m-1" id="add-user">Add User</button>');
        $('#user_modal_heading').html("Add User");
        $('#saveBtn').val("create-user");
        $('#user_form').trigger("reset");
        $('form[name="user_form"]')[0].reset();
        $('#user_modal').modal('show');
    });
    
    $('body').on('click', '.edit', function () {
        $(".is-invalid").removeClass("is-invalid");
        $('.invalid-feedback').html("");
        var id = $(this).data('id');
        $('form[name="user_form"]')[0].reset();
		$("[name='id']").val(id); // form cleared, so sets id again :)
        populateForm(id);
        renderPracticeTable(id);
        $('#edit_user_modal').modal('show');
    });

    $('body').on('click', '.change-status', function (){
        console.log('changed status');
        var confirm = confirm("Are you sure you want to Deactive this user?");
        if (confirm == true) {
            alert('yessss');
        } 
    });
};

/**
 * Export the module
 */
window.orgusers = {
    init: init,
    onErrors: onErrors,
    onResult: onResult,
    onSubmit: onSubmit
};